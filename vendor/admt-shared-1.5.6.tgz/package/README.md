# ADMT shared

ADMT 各端共用的纯 TypeScript 包 `@admt/shared`。独立仓库、独立版本，不依赖桌面端或 Web 端。

## 放置规则

可以放入：跨端一致的类型定义、常量、i18n 文案、无副作用的纯函数。

禁止放入：Tauri API、WebUSB、DOM 操作、平台判断、子进程、文件读写、任何副作用或需要构建时环境的代码。

平台相关实现必须留在各自仓库：

- 桌面端 `admt`：`src/` 与 `src-tauri/src/`
- Web 端 `admt-web`：`web/src/platform/`

## 使用方式

发布到 npm 或 GitHub Packages 后，各端在 `package.json` 中以版本号依赖：

```json
"@admt/shared": "^1.5.6"
```

新增共享代码时先确认它不依赖任何平台能力，再在这里发布新版本；两个应用各自升级版本，不做跨仓库源码引用。

## 本地构建

```bash
npm ci
npm run typecheck
npm run build
```
